#ifndef GD32F30X_IT_H
#define GD32F30X_IT_H

void SysTick_Handler(void);

#endif /* GD32F30X_IT_H */
