#include "main.h"

BTN2Flag btn2Flag = {0};
uint32_t btn2_ms = 0;
BTN2State btn2State = BTN2_IDLE;

void btn2_process(void)
{
    switch (btn2State)
	{
		case BTN2_IDLE:
            if (!(GPIO_ISTAT(GPIOB) & (1U << 7)))
            {
                btn2State = BTN2_DEBOUNCE_PRESS;
                btn2_ms = g_ms;
            }
			break;

		case BTN2_DEBOUNCE_PRESS:
			if(g_ms - btn2_ms >= 20)
			{
				if(!(GPIO_ISTAT(GPIOB) & (1U << 7)))
				{
					btn2State = BTN2_PRESSED;
					btn2Flag.status = 1;
				}
				else
				{
					btn2State = BTN2_IDLE;
				}
			}
			break;

		case BTN2_PRESSED:
			if((GPIO_ISTAT(GPIOB) & (1U << 7)))
			{
				btn2State = BTN2_DEBOUNCE_RELEASE;
				btn2_ms = g_ms;
			}
			break;

		case BTN2_DEBOUNCE_RELEASE:
			if(g_ms - btn2_ms >= 20)
			{
				if((GPIO_ISTAT(GPIOB) & (1U << 7)))
				{
					btn2State = BTN2_IDLE;
				}
				else
				{
					btn2State = BTN2_PRESSED;
				}
			}
			break;
		
		default:
			btn2State = BTN2_IDLE;
			break;
	}
}

void btn2_init(void)
{
    RCU_APB2EN |= (1U << 3);

    GPIO_CTL0(GPIOB) &= ~(0b1111 << 28);
    GPIO_CTL0(GPIOB) |= (0b1000 << 28);

    GPIO_OCTL(GPIOB) |= (1U << 7);
}