#include "gd32f30x.h"

#ifndef BTN2_H
#define BTN2_H

typedef struct
{
    uint8_t status : 1;
} BTN2Flag;
extern BTN2Flag btn2Flag;

typedef uint8_t BTN2State;
enum
{
    BTN2_IDLE,             
    BTN2_DEBOUNCE_PRESS,   
    BTN2_PRESSED,          
    BTN2_DEBOUNCE_RELEASE, 
    BTN2_RELEASE          
};

void btn2_init(void);
void btn2_process(void);

#endif