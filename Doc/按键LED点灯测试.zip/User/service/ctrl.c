#include "main.h"

uint32_t ctrl_ms = 0;
CTRLState ctrlState = CTRL_IDLE;

void ctrl_process(void)
{
    switch (ctrlState)
    {
        case CTRL_IDLE:
            if (btn1Flag.status)
            {
                btn1Flag.status = 0;

                ledFlag.status = 1;

                ctrlState = CTRL_WORKING;
            }
            break;

        case CTRL_WORKING:
            if(btn1Flag.status)
            {
                btn1Flag.status = 0;
                
                if(ledFlag.status == 1)
                {
                    ledFlag.status = 2;
                }
                else if(ledFlag.status == 2)
                {
                    ledFlag.status = 1;
                }
            }

            if(btn2Flag.status)
            {
                btn2Flag.status = 0;

                ctrlState = CTRL_STOP;
            }
            break;

        case CTRL_STOP:
            btn1Flag.status = 0;
            btn2Flag.status = 0;
            ledFlag.status = 0;

            ctrlState = CTRL_IDLE;
            break;
        
        default:
            ctrlState = CTRL_IDLE;
            break;
    }
}