#ifndef MAIN_H
#define MAIN_H

#include "gd32f30x.h"
#include "gd32f30x_it.h"
#include "sysck.h"
#include "timing.h"
#include "btn1.h"
#include "btn2.h"
#include "led.h"
#include "ctrl.h"

#endif /* MAIN_H */
