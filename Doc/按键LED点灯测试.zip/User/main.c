#include "main.h"

int main(void)
{
    sysck_init();
    systick_init();
    tim1_us_init();

    btn1_init();
    btn2_init();
    led_init();

    while(1)
    {
        ctrl_process();
        btn1_process();
        btn2_process();
        led_process();
    }
}
