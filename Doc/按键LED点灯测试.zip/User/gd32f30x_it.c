#include "main.h"

void SysTick_Handler(void)
{
    g_ms++;
}
